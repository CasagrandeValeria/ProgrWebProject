const express = require("express");
const router = express.Router();
const db = require("../db.js");

/* API to search users given an input string */
router.get("/search", async (req, res) => {
  try {
    const mongo = db.getDb();
    const query = req.query.q;
    const queryString = new RegExp(query, "i"); //case insensitive
    const users = await mongo.collection("users").find(
        {
          $or: [
            { name: queryString },
            { surname: queryString },
            { username: queryString },
          ],
        },
        {
          projection: {
            _idU: true,
            name: true,
            surname: true,
            username: true,
          },
        }
      )
      .toArray();
    res.json(users);
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: "HTTP internal error occurred." });
  }
});

module.exports = router;
