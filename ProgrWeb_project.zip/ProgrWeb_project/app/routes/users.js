const express = require("express");
const router = express.Router();
const db = require("../db.js");

/* API to get info about one user */
router.get("/users/:id", async (req, res) => {
  const mongo = db.getDb();
  const id = !isNaN(parseInt(req.params.id)) ? parseInt(req.params.id) : null;
  if (!id) {
    return res.status(404).send({ error: "User ID is invalid." });
  }
  const user = await mongo.collection("users").findOne({ _idU: id });
  res.json(user);
});

/* API to obtain user data from their username */
router.get("/users/", async (req, res) => {
  try {
    const mongo = db.getDb();
    const queryUsername = req.query.q;
    const users = await mongo.collection("users").find({ username: queryUsername, }).toArray();
    res.json(users);
  } catch (err) {
    console.error(err);
    res.status(500).send({ error: "HTTP internal error occurred." });
  }
});

module.exports = router;
