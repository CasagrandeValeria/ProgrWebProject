const express = require("express");
const router = express.Router();
const db = require("../db.js");
const jwt = require("jsonwebtoken");
const { message } = require("statuses");

/* API to LIKE a message */
router.post("/like/:idMessage", async (req, res) => {
  try {
    const mongo = db.getDb();
    const token = req.cookies.jwt;
    if (!token){
      return res.status(401).json({message: "Anauthorized: please log in to like a message."})
    }
    const usernameToSearch = jwt.verify(token, "web_app_secret");
    const idMsg = !isNaN(parseInt(req.params.idMessage))? parseInt(req.params.idMessage) : null;
    if (!idMsg) {
      return res.status(404).send({ error: "Message ID is invalid." });
    }
    const userWhoLikes = await mongo.collection("users").findOne({ username: usernameToSearch.id });
    const alreadyLiked = await mongo.collection("like")
    .findOne({ usernameWhoLiked: userWhoLikes.username, idLikedMessage: idMsg });
    if (alreadyLiked) {
      return res.status(400).send({ error: "you have already liked this message." });
    }
    const lastLike = await mongo.collection("like").findOne({}, { sort: { _idL: -1 } });
    let lastLikeId = lastLike?._idL !== undefined ? lastLike._idL : 0;
    lastLikeId++;
    const newLike = {
      _idL: lastLikeId,
      usernameWhoLiked: userWhoLikes.username,
      idLikedMessage: idMsg,
    };
    await mongo.collection("like").insertOne(newLike);
    res.json(newLike);
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "HTTP internal error occurred." });
  }
});

/* API to REMOVE LIKE from message */
router.delete("/like/:idMessage", async (req, res) => {
  try {
    const mongo = db.getDb();
    const token = req.cookies.jwt;
    if (!token){
      return res.status(401).json({message: "Anauthorized: please log in to remove a like."})
    }
    const usernameToSearch = jwt.verify(token, "web_app_secret");
    const idMsg = !isNaN(parseInt(req.params.idMessage)) ? parseInt(req.params.idMessage) : null;
    if (!idMsg) {
      return res.status(404).send({ error: "Invalid message ID" });
    }
    const userWhoDislikes = await mongo.collection("users").findOne({ username: usernameToSearch.id });
    const likeToRemove = await mongo.collection("like")
    .findOne({ usernameWhoLiked: userWhoDislikes.username, idLikedMessage: idMsg });
    if (!likeToRemove) {
      return res.status(404).send({ error: "There is no like to remove." });
    }
    let likes = await mongo.collection("like").deleteOne(likeToRemove);
    res.json(likes);
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "HTTP internal error occurred." });
  }
});

/* API to read the number of likes a message has */
router.get("/like/:idMessage", async (req, res) => {
  const mongo = db.getDb();
  const idMsg = !isNaN(parseInt(req.params.idMessage)) ? parseInt(req.params.idMessage) : null;
  if (!idMsg) {
    return res.status(404).send({ error: "Message ID in invalid." });
  }
  const countLikes = async (idMsg) => {
    const likes = await mongo.collection("like").countDocuments({ idLikedMessage: idMsg });
    return likes;
  };
  const result = await countLikes(idMsg);
  res.json({ count: result });
});

/* API to CHECK IF the currently authenticated user has alread liked a message or not */
router.get("/checkLike/:idMessage", async (req, res) => {
  try {
    const mongo = db.getDb();
    const token = req.cookies.jwt;
    if (!token){
      return res.status(401).json({message: "Anauthorized: please log in to check the likes."})
    }
    const usernameToSearch = jwt.verify(token, "web_app_secret");
    const idMsg = !isNaN(parseInt(req.params.idMessage)) ? parseInt(req.params.idMessage): null;
    if (!idMsg) {
      return res.status(404).send({ error: "Message ID is invalid" });
    }
    const userToCheck = await mongo.collection("users").findOne({ username: usernameToSearch.id });
    const foundLike = await mongo.collection("like")
    .findOne({ usernameWhoLiked: userToCheck.username, idLikedMessage: idMsg });
    if (!foundLike) {
      res.json({ hasLiked: false });
    } else {
      res.json({ hasLiked: true });
    }
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "HTTP internal server error" });
  }
});

module.exports = router;
