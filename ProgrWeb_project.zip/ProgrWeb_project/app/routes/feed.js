const express = require("express");
const router = express.Router();
const db = require("../db.js");
const jwt = require("jsonwebtoken");

/* API to see your FEED */
router.get("/feed", async (req, res) => {
  try {
    const mongo = db.getDb();
    const token = req.cookies.jwt;
    if (!token){
      return res.status(401).json({message: "Anauthorized: please log in to see your feed."})
    }
    const usernameToSearch = jwt.verify(token, "web_app_secret");
    
    const userToDisplay = await mongo.collection("users").findOne({ username: usernameToSearch.id });
    const theirFollowedPeople = await mongo.collection("followers").find({ theFollower: userToDisplay.username })
      .toArray();
    const theirFollowedMsgs = await mongo.collection("messages").aggregate([
        {
          $match: {
            author: { $in: theirFollowedPeople.map((flw) => flw.theFollowed) },
          },
        },
        {
          $lookup: {
            from: "users",
            localField: "author",
            foreignField: "username",
            as: "authorInfo",
          },
        },
        {
          $project: {
            _idM: true,
            author: true,
            date: true,
            text: true,
            authorId: "$authorInfo._idU",
          },
        },
      ])
      .toArray();
    res.json(theirFollowedMsgs);
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "HTTP internal server error" });
  }
});

module.exports = router;
