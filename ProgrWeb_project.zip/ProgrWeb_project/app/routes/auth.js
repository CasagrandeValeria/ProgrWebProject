const express = require("express");
const session = require("express-session");
const router = express.Router();
const db = require("../db.js");
const jwt = require("jsonwebtoken");

/* API to SIGNUP */
router.post("/signup", async (req, res) => {
  try {
    const mongo = db.getDb();
    const userData = req.body;
    const username = req.body.username;
    const thisUser = await mongo.collection("users").findOne({ username: username });
    if (thisUser) {
      res.status(409).json({ message: "This username already exists, please choose another one." });
    } else if ( !userData.username ||
                !userData.password ||
                !userData.name ||
                !userData.surname ||
                !userData.bio) {
      res.status(401).json({ message: "All fields are necessary: please fill the missing fields." });
    } else {
      const lastUser = await mongo.collection("users").findOne({}, { sort: { _idU: -1 } });
      let lastUserId = lastUser?._idU === undefined ? 0 : lastUser._idU;
      lastUserId++;
      userData._idU = lastUserId;
      console.log(userData);
      await mongo.collection("users").insertOne(userData);
      const token = jwt.sign({ id: userData.username }, "web_app_secret", {
        expiresIn: 86400,
      });
      res.cookie("jwt", token, { httpOnly: true });
      res.json({ message: "New user added successfully." });
    }
  } catch (error) {
    res.status(500).json({ message: "HTTP internal error occurred." });
  }
});

/* API to SIGNIN */
router.post("/signin", async (req, res) => {
  try {
    const mongo = db.getDb();
    const username = req.body.username;
    const password = req.body.password;
    const thisUser = await mongo.collection("users").findOne({ username: username });
    console.log(thisUser);
    if (!thisUser) {
      res.status(401).json({ message: "Incorrect username: user not found." });
    } else if (thisUser.password !== password) {
      res.status(401).json({ message: "Incorrect password." });
    } else {
      const token = jwt.sign({ id: thisUser.username }, "web_app_secret", {
        expiresIn: 86400,
      });
      res.cookie("jwt", token, { httpOnly: true });
      res.json({ message: "Authenticated" });
    }
  } catch (err) {
    res.status(500).json({ error: "HTTP internal server error" });
  }
});

/* API to CHECK IF a user is authenticated or not */
router.get("/control", async (req, res) => {
  try {
    const token = req.cookies.jwt;
    if (!token) {
      res.status(401).json({ isAuthenticated: false });
    } else {
      const decoded = jwt.verify(token, "web_app_secret");
      res.json({ isAuthenticated: true, currentUsername: decoded.id });
    }
  } catch (err) {
    res.status(401).json({ isAuthenticated: false });
  }
});

/* API to LOG OUT */
router.post("/signout", (req, res) => {
  try {
    const token = req.cookies.jwt;
    if (!token) {
      res.status(401).json({ message: "An unauthenticated user cannot log out." });
    } else {
      const decoded = jwt.verify(token, "web_app_secret");
      req.session.destroy((err) => {
        if (err) {
          console.error(err);
          res.status(500).json({ message: "Something failed during log out procedure." });
        } else {
          res.clearCookie("jwt");
          res.status(200).json({ message: "User logged out successfully." });
        }
      });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Something failed during log out procedure." });
  }
});

module.exports = router;
