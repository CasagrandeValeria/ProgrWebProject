const express = require("express");
const router = express.Router();
const db = require("../db.js");
const jwt = require("jsonwebtoken");

/* API for the authenticated user to get info about itself */
router.get("/whoami", async (req, res) => {
  try {
    const mongo = db.getDb();
    const token = req.cookies.jwt;
    const usernameToSearch = jwt.verify(token, "web_app_secret");
    const user = await mongo.collection("users").findOne({ username: usernameToSearch.id });
    if (!user) {
      return res.status(401).json({ error: "Unauthorized: only logged in users can get info about themselves." });
    }
    res.json(user);
  } catch (err) {
    console.log(err);
    res.status(500).json({ error: "HTTP internal server error" });
  }
});

module.exports = router;
