const express = require("express");
const router = express.Router();
const db = require("../db.js");
const jwt = require("jsonwebtoken");

/* API to SEE your followers */
router.get("/followers/:id", async (req, res) => {
  const mongo = db.getDb();
  const id = !isNaN(parseInt(req.params.id)) ? parseInt(req.params.id) : null;
  if (!id) {
    return res.status(404).send({ error: "User ID is invalid." });
  }
  const userToSearch = await mongo.collection("users").findOne({ _idU: id });
  const theirFollowers = await mongo.collection("followers")
  .find({ theFollowed: userToSearch.username })
    .toArray();
  res.json(theirFollowers);
});

/* API to FOLLOW someone */
router.post("/followers/:userId", async (req, res) => {
  try {
    const mongo = db.getDb();
    const token = req.cookies.jwt;
    if (!token){
      return res.status(401).json({message: "Anauthorized: please log in to follow someone."})
    }
    const userToSearch = jwt.verify(token, "web_app_secret");
    const userWhoWillFollow = await mongo.collection("users").findOne({ username: userToSearch.id });
    const userId = !isNaN(parseInt(req.params.userId))
      ? parseInt(req.params.userId) : null;
    if (!userId) {
      return res.status(404).send({ error: "User ID in invalid." });
    }
    const userWhoWillBeFollowed = await mongo.collection("users").findOne({ _idU: userId });
    if (!userWhoWillBeFollowed) {
      return res.status(404).send({ error: "This user does not exists." });
    }
    const lastFollow = await mongo.collection("followers").findOne({}, { sort: { _idF: -1 } });
    let lastFollowId = lastFollow?._idF !== undefined ? lastFollow._idF : 0;
    lastFollowId++;
    const newFollower = {
      _idF: lastFollowId,
      theFollower: userWhoWillFollow.username,
      theFollowed: userWhoWillBeFollowed.username,
    };
    let followers = await mongo.collection("followers").insertOne(newFollower);
    res.json(followers);
  } catch (error) {
    return res.status(500).json({ error: "HTTP internal error occurred." });
  }
});

/* API to UNFOLLOW someone */
router.delete("/followers/:id", async (req, res) => {
  try {
    const mongo = db.getDb();
    const token = req.cookies.jwt;
    if (!token){
      return res.status(401).json({message: "Anauthorized: please log in to delete a follow."})
    }
    const usernameToSearch = jwt.verify(token, "web_app_secret");
    const userWhoWillUnfollow = await mongo.collection("users")
    .findOne({ username: usernameToSearch.id });
    console.log(userWhoWillUnfollow.username);
    const userId = !isNaN(parseInt(req.params.id)) ? parseInt(req.params.id) : null;
    if (!userId) {
      return res.status(404).send({ error: "Invalid user ID" });
    }
    let followers = await mongo.collection("followers")
    .deleteOne({ theFollower: userWhoWillUnfollow.username });
    res.json(followers);
  } catch (error) {
    return res.status(500).json({ error: "HTTP internal server error" });
  }
});

/* API to CHECK IF the currently authenticated user follows another user (by their ID) */
router.get("/checkFollow/:id", async (req, res) => {
  try {
    const mongo = db.getDb();
    const token = req.cookies.jwt;
    if (!token){
      return res.status(401).json({message: "Anauthorized: please log in to check a follow."})
    }
    const usernameToSearch = jwt.verify(token, "web_app_secret");
    const currentUser = await mongo.collection("users").findOne({ username: usernameToSearch.id });
    if (!currentUser) {
      return res.status(401).json({ error: "Unauthorized: only authenticated users can check this." });
    }
    const userToFollowOrNotId = !isNaN(parseInt(req.params.id)) ? parseInt(req.params.id) : null;
    if (!userToFollowOrNotId) {
      return res.status(404).send({ error: "Invalid user ID" });
    }
    const userToFollowOrNot = await mongo.collection("users").findOne({ _idU: userToFollowOrNotId });
    const isFollowing = await mongo.collection("followers").findOne({
      theFollower: currentUser.username,
      theFollowed: userToFollowOrNot.username,
    });
    if (!isFollowing) {
      res.json({ following: false });
    } else {
      res.json({ following: true });
    }
  } catch (err) {
    res.json({ message: "HTTP internal error occurred." });
  }
});

module.exports = router;
