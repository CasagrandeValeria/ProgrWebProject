const express = require("express");
const router = express.Router();
const db = require("../db.js");
const jwt = require("jsonwebtoken");

/* API to get ALL messages */
router.get("/messages", async (req, res) => {
  const mongo = db.getDb();
  const allMessages = await mongo.collection("messages").aggregate([
      {
        $lookup: {
          from: "users",
          localField: "author",
          foreignField: "username",
          as: "authorInfo",
        },
      },
      {
        $project: {
          _idM: true,
          date: true,
          text: true,
          author: true,
          authorId: "$authorInfo._idU",
        },
      },
    ])
    .toArray();
  res.json(allMessages);
});

/* API to get ONE USER's messages */
router.get("/messages/:userId", async (req, res) => {
  const mongo = db.getDb();
  const id = !isNaN(parseInt(req.params.userId)) ? parseInt(req.params.userId) : null;
  if (!id) {
    return res.status(404).send({ error: "User ID is invalid." });
  }
  const user = await mongo.collection("users").findOne({ _idU: id });
  const thisUserMessages = await mongo.collection("messages").aggregate([
      {
        $match: { author: user.username },
      },
      {
        $lookup: {
          from: "users",
          localField: "author",
          foreignField: "username",
          as: "authorInfo",
        },
      },
      {
        $project: {
          _idM: true,
          date: true,
          text: true,
          author: true,
          authorId: "$authorInfo._idU",
        },
      },
    ])
    .toArray();

  res.json(thisUserMessages);
});

/* API to POST a message */
router.post("/messages", async (req, res) => {
  try {
    const mongo = db.getDb();
    const token = req.cookies.jwt;
    if (!token){
      return res.status(401).json({message: "Anauthorized: please log in to post a message."})
    }
    const usernameToSearch = jwt.verify(token, "web_app_secret");
    const userWhoPosts = await mongo.collection("users").findOne({ username: usernameToSearch.id });
    if (!userWhoPosts) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    const message = req.body.text;
    let currentDate = new Date();
    const lastMessage = await mongo.collection("messages").findOne({}, { sort: { _idM: -1 } });
    let lastMsgId = lastMessage?._idM !== undefined ? lastMessage._idM : 0;
    lastMsgId++;
    const newMessage = {
      _idM: lastMsgId,
      author: userWhoPosts.username,
      date: currentDate,
      text: message,
    };
    await mongo.collection("messages").insertOne(newMessage);
    res.json(newMessage);
  } catch (err) {
    return res.status(500).json({ error: "HTTP internal error occurred." });
  }
});

/* API to get ONE specific message */
router.get("/messages/:userId/:idMsg", async (req, res) => {
  const mongo = db.getDb();
  const userId = !isNaN(parseInt(req.params.userId)) ? parseInt(req.params.userId) : null;
  const msgId = !isNaN(parseInt(req.params.idMsg)) ? parseInt(req.params.idMsg) : null;
  if (!userId || !msgId) {
    return res.status(404).send({ error: "Invalid ID for user and/or message" });
  }
  const user = await mongo.collection("users").findOne({ _idU: userId });
  let message = await mongo.collection("messages").findOne({ _idM: msgId, author: user.username });
  res.json(message);
});

module.exports = router;
