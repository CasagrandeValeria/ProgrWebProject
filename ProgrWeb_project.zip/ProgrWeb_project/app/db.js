const { MongoClient } = require("mongodb");
const url = "mongodb://mongo:27017";
const client = new MongoClient(url);

let _db;

module.exports = {
  connect: async () => {
    await client.connect();
    _db = client.db("CarrierDB");
  },
  getDb: () => _db,
};