mongo --quiet --eval "
    db = db.getSiblingDB('CarrierDB');
    db.dropDatabase();
"