mongo --quiet --eval "
    db = db.getSiblingDB('CarrierDB');
    db.users.insertOne({_idU: 1, 
                        name: \"Albert\",
                        surname: \"Allen\",
                        username: \"AlbertTheAxolotl\", 
                        password: \"pw1\", 
                        bio: \"Keep your eyes open for sudden, unexpected beauty.\",
                        });
    db.users.insertOne({_idU: 2, 
                        name: \"Barbara\",
                        surname: \"Brown\",
                        username: \"BoxingBarbie\", 
                        password: \"pw2\", 
                        bio: \"Three things I value most: empathy, which makes humanity worth trusting in; kindness, which makes days worth facing; and boxing, in case of lacking of the previous two.\",
                        });
    db.users.insertOne({_idU: 3, 
                        name: \"Catherine\",
                        surname: \"Carter\",
                        username: \"CallMeCathy\", 
                        password: \"pw3\", 
                        bio: \"Just like Wuthering Heights, occasionally toxic but never boring. And then, we could always look back at it and have a laugh.\",
                        });
    db.users.insertOne({_idU: 4, 
                        name: \"David\",
                        surname: \"Dylan\",
                        username: \"DirectDavid\", 
                        password: \"pw4\", 
                        bio: \"I am a very straightforward person. Nothing personal but if what I say offends you, it's actually you being offended by reality. Peace!\",
                        });
    db.users.insertOne({_idU: 5, 
                        name: \"Eveline\",
                        surname: \"Evans\",
                        username: \"EventuallyEve\", 
                        password: \"pw5\", 
                        bio: \"People criticize me by saying that I spend too much time reading fantasy novels and end up loosing contact with reality. I mean, that's the purpouse! Have you seen it out there?\",
                        });
    db.users.insertOne({_idU: 6, 
                        name: \"Fanny\",
                        surname: \"Fitzgerald\",
                        username: \"FannyThePhoenix\", 
                        password: \"pw6\", 
                        bio: \"Be your best self by never leaving the strenuous path of self improvement. May the Force be with you.\",
                        });
    db.users.insertOne({_idU: 7, 
                        name: \"Gerald\",
                        surname: \"Gulliver\",
                        username: \"Gerald.\", 
                        password: \"pw7\", 
                        bio: \"I don't talk much.\",
                        });
    db.users.insertOne({_idU: 8, 
                        name: \"Harold\",
                        surname: \"Hansington\",
                        username: \"SirHansington\", 
                        password: \"pw8\", 
                        bio: \"Greetings to every person I occur to share this platform with, I do hope this message finds you well.\",
                        });
    db.users.insertOne({_idU: 9, 
                        name: \"Ian\",
                        surname: \"Irwin\",
                        username: \"Ian95\", 
                        password: \"pw9\", 
                        bio: \"Mainly looking for un-dramatic people to share thoughts about useless overthinking. I know it's plenty of us.\",
                        });
    db.users.insertOne({_idU: 10, 
                        name: \"Jason\",
                        surname: \"Jones\",
                        username: \"J_theJack\", 
                        password: \"pw10\", 
                        bio: \"Life is like the game of poker: you value your odds, bet what you are willing to loose, play your best game with what fate chose to give you - but there will always be someone able to win over you. Enjoy the experience.\",
                        });
    db.users.find({}, {_idU: 1, name: 1, surname: 1, username: 1, password: 1, bio: 1}).forEach(printjson);
    print(\"You visualized the collection of all users\");
"
#l'ultimo è un window.print()
#-------------------------------------------------------------------------------------------------------------
echo -e "\n"
mongo --quiet --eval "
    db = db.getSiblingDB('CarrierDB');
    db.messages.insertOne({_idM: 1, 
                            author: \"DirectDavid\",
                            date: new Date(\"2023-05-18T09:26:47Z\"),
                            text: \"My uncle came up to me today and scolded me, calling me unapproachable. So I said to him 'Yet here you are.' He didn't like it.\"
    });
    db.messages.insertOne({_idM: 2, 
                            author: \"AlbertTheAxolotl\",
                            date: new Date(\"2023-05-21T23:11:51Z\"),
                            text: \"For everyone here looking for an answer: 42.\"
    });
    db.messages.insertOne({_idM: 3, 
                            author: \"CallMeCathy\",
                            date: new Date(\"2023-05-21T21:35:40Z\"),
                            text: \"'Terror made me cruel.' - Mr. Lockwood\"
    });
    db.messages.insertOne({_idM: 4, 
                            author: \"CallMeCathy\",
                            date: new Date(\"2023-05-22T22:14:27Z\"),
                            text: \"'If all else perished, and he remained, I should still continue to be; and if all else remained, and he were annihilated, the universe would turn to a mighty stranger'. - Catherine Earnshaw\"
    });
     db.messages.insertOne({_idM: 5, 
                            author: \"AlbertTheAxolotl\",
                            date: new Date(\"2023-05-22T02:15:26Z\"),
                            text: \"Although sure there are other living beings out there, somewhere in space, I really think we should not be looking for them. Because the fear of them wanting to murder us, added to the inability to communicate, would be the reason for us to murder them first.\"
    });
    db.messages.insertOne({_idM: 6, 
                            author: \"DirectDavid\",
                            date: new Date(\"2023-05-23T08:53:06Z\"),
                            text: \"This morning started out great: I woke up on time, had breakfast and went for a walk outside. That's when I met people.\"
    });
    db.messages.insertOne({_idM: 7, 
                            author: \"EventuallyEve\",
                            date: new Date(\"2023-05-24T14:19:28Z\"),
                            text: \"Anyone here wearing a blanket as a cape when it's raining outside and running under the rain, pretending to be an elvish mage who feels their powers regenerated? Just me?\"
    });
    db.messages.insertOne({_idM: 8, 
                            author: \"Ian95\",
                            date: new Date(\"2023-05-26T00:43:19Z\"),
                            text: \"I'm sure I'm not the only one replaying conversations in my head, looking for other things that I should have said instead, and get trapped into a spiral of guilt. Am I?\"
    });
    db.messages.insertOne({_idM: 9, 
                            author: \"AlbertTheAxolotl\",
                            date: new Date(\"2023-05-27T11:36:45Z\"),
                            text: \"I think it's mind blowing the fact that we are currently on a big rock spinning across the universe at 1,3 MILLION km/h. Reality is insane. It's just real, so no one really cares.\"
    });
    db.messages.insertOne({_idM: 10, 
                            author: \"AlbertTheAxolotl\",
                            date: new Date(\"2023-05-27T07:08:52Z\"),
                            text: \"Croissants make every morning better, so let me tell you this: there is a giant, cosmic croissant-shaped shield made of solar winds wrapped around our solar system which protects life on Earth from cosmic radiation. Enjoy your breakfast!\"
    });
    db.messages.insertOne({_idM: 11, 
                            author: \"Ian95\",
                            date: new Date(\"2023-05-29T14:29:58Z\"),
                            text: \"Today the waiter told me 'Enjoy your meal!' and I said 'You too!'... Why am I like this.\"
    });
    db.messages.insertOne({_idM: 12, 
                            author: \"Ian95\",
                            date: new Date(\"2023-06-01T17:15:42Z\"),
                            text: \"That weird dance you do when you have to walk over a floor someone else has just mopped, and you want them to understand how sorry you are but you know you'll end up stepping on the wet floor more times that you would have done if you had just walked normally.\"
    });
    db.messages.insertOne({_idM: 13, 
                            author: \"EventuallyEve\",
                            date: new Date(\"2023-06-03T08:27:43Z\"),
                            text: \"Sometimes when I am on the bus I try to think about it as a futuristic carriage, dragged by metal horses powered with a potion that can only be created in special forges in the depths of Earth's mantle.\"
    });
    db.messages.insertOne({_idM: 14, 
                            author: \"J_theJack\",
                            date: new Date(\"2023-06-07T22:54:11Z\"),
                            text: \"Lost a bet with a friend, so here I am writing the first thing that comes to my mind: salamander.\"
    });
    db.messages.insertOne({_idM: 15, 
                            author: \"DirectDavid\",
                            date: new Date(\"2023-06-07T19:38:46Z\"),
                            text: \"My uncle came up to me and said: 'You are too old to be un-coupled, David.' ...you are too old to be alive, Ben, yet here we are.\"
    });
    db.messages.find({}, {_idM: 1, author: 1, date: 1, text: 1}).forEach(printjson);
    print(\"You visualized the collection of all messages\");
"
#-------------------------------------------------------------------------------------------------------------
echo -e "\n"
mongo --quiet --eval "
    db = db.getSiblingDB('CarrierDB');
    db.followers.insertOne({_idF: 1,
                            theFollower: \"Gerald.\",
                            theFollowed: \"DirectDavid\"
    });
    db.followers.insertOne({_idF: 2,
                            theFollower: \"SirHansington\",
                            theFollowed: \"DirectDavid\"
    });
    db.followers.insertOne({_idF: 3,
                            theFollower: \"CallMeCathy\",
                            theFollowed: \"DirectDavid\"
    });
    db.followers.insertOne({_idF: 4,
                            theFollower: \"Ian95\",
                            theFollowed: \"DirectDavid\"
    });
    db.followers.insertOne({_idF: 5,
                            theFollower: \"BoxingBarbie\",
                            theFollowed: \"DirectDavid\"
    });
    db.followers.insertOne({_idF: 6,
                            theFollower: \"DirectDavid\",
                            theFollowed: \"Gerald.\"
    });
    db.followers.insertOne({_idF: 7,
                            theFollower: \"CallMeCathy\",
                            theFollowed: \"SirHansington\"
    });
    db.followers.insertOne({_idF: 8,
                            theFollower: \"CallMeCathy\",
                            theFollowed: \"AlbertTheAxolotl\"
    });
    db.followers.insertOne({_idF: 9,
                            theFollower: \"Gerald.\",
                            theFollowed: \"AlbertTheAxolotl\"
    });
    db.followers.insertOne({_idF: 10,
                            theFollower: \"DirectDavid\",
                            theFollowed: \"AlbertTheAxolotl\"
    });
    db.followers.insertOne({_idF: 11,
                            theFollower: \"SirHansington\",
                            theFollowed: \"AlbertTheAxolotl\"
    });
    db.followers.insertOne({_idF: 12,
                            theFollower: \"Ian95\",
                            theFollowed: \"EventuallyEve\"
    });
    db.followers.insertOne({_idF: 13,
                            theFollower: \"BoxingBarbie\",
                            theFollowed: \"EventuallyEve\"
    });
    db.followers.insertOne({_idF: 14,
                            theFollower: \"EventuallyEve\",
                            theFollowed: \"Ian95\"
    });
    db.followers.insertOne({_idF: 15,
                            theFollower: \"AlbertTheAxolotl\",
                            theFollowed: \"Ian95\"
    });
    db.followers.insertOne({_idF: 16,
                            theFollower: \"AlbertTheAxolotl\",
                            theFollowed: \"DirectDavid\"
    });
    db.followers.insertOne({_idF: 17,
                            theFollower: \"AlbertTheAxolotl\",
                            theFollowed: \"EventuallyEve\"
    });
    db.followers.insertOne({_idF: 18,
                            theFollower: \"EventuallyEve\",
                            theFollowed: \"AlbertTheAxolotl\"
    });
    db.followers.insertOne({_idF: 19,
                            theFollower: \"EventuallyEve\",
                            theFollowed: \"CallMeCathy\"
    });
    db.followers.insertOne({_idF: 20,
                            theFollower: \"EventuallyEve\",
                            theFollowed: \"SirHansington\"
    });
    db.followers.find({}, { _idF: 1, theFollower: 1, theFollowed: 1}).forEach(printjson);
    print(\"You visualized the collection of all followers\");
"
#-------------------------------------------------------------------------------------------------------------

echo -e "\n"
mongo --quiet --eval "
    db = db.getSiblingDB('CarrierDB');
    db.like.insertOne({_idL: 1, 
                        idLikedMessage: 2,
                        usernameWhoLiked: \"BoxingBarbie\",
    });
    db.like.insertOne({_idL: 2, 
                        idLikedMessage: 2,
                        usernameWhoLiked: \"EventuallyEve\",
    });
    db.like.insertOne({_idL: 3, 
                        idLikedMessage: 2,
                        usernameWhoLiked: \"Ian95\",
    });
    db.like.insertOne({_idL: 4, 
                        idLikedMessage: 2,
                        usernameWhoLiked: \"DirectDavid\",
    });
    db.like.insertOne({_idL: 5, 
                        idLikedMessage: 2,
                        usernameWhoLiked: \"SirHansington\",
    });
    db.like.insertOne({_idL: 6, 
                        idLikedMessage: 2,
                        usernameWhoLiked: \"Gerald.\",
    });
    db.like.insertOne({_idL: 7, 
                        idLikedMessage: 1,
                        usernameWhoLiked: \"Gerald.\",
    });
    db.like.insertOne({_idL: 8, 
                        idLikedMessage: 1,
                        usernameWhoLiked: \"J_theJack\",
    });
    db.like.insertOne({_idL: 9, 
                        idLikedMessage: 1,
                        usernameWhoLiked: \"Ian95\",
    });
    db.like.insertOne({_idL: 10, 
                        idLikedMessage: 1,
                        usernameWhoLiked: \"BoxingBarbie\",
    });
    db.like.insertOne({_idL: 11, 
                        idLikedMessage: 6,
                        usernameWhoLiked: \"Gerald.\",
    });
    db.like.insertOne({_idL: 12, 
                        idLikedMessage: 7,
                        usernameWhoLiked: \"CallMeCathy\",
    });
    db.like.insertOne({_idL: 13, 
                        idLikedMessage: 8,
                        usernameWhoLiked: \"EventuallyEve\",
    });
    db.like.insertOne({_idL: 14, 
                        idLikedMessage: 10,
                        usernameWhoLiked: \"SirHansington\",
    });
    db.like.insertOne({_idL: 15, 
                        idLikedMessage: 10,
                        usernameWhoLiked: \"EventuallyEve\",
    });
    db.like.insertOne({_idL: 16, 
                        idLikedMessage: 10,
                        usernameWhoLiked: \"DirectDavid\",
    });
    db.like.insertOne({_idL: 17, 
                        idLikedMessage: 12,
                        usernameWhoLiked: \"EventuallyEve\",
    });
    db.like.insertOne({_idL: 18, 
                        idLikedMessage: 12,
                        usernameWhoLiked: \"DirectDavid\",
    });
    db.like.insertOne({_idL: 19, 
                        idLikedMessage: 3,
                        usernameWhoLiked: \"EventuallyEve\",
    });
    db.like.insertOne({_idL: 20, 
                        idLikedMessage: 3,
                        usernameWhoLiked: \"SirHansington\",
    });
    db.like.insertOne({_idL: 21, 
                        idLikedMessage: 4,
                        usernameWhoLiked: \"EventuallyEve\",
    });
    db.like.insertOne({_idL: 22, 
                        idLikedMessage: 4,
                        usernameWhoLiked: \"AlbertTheAxolotl\",
    });
    db.like.insertOne({_idL: 23, 
                        idLikedMessage: 5,
                        usernameWhoLiked: \"DirectDavid\",
    });
    db.like.insertOne({_idL: 24, 
                        idLikedMessage: 9,
                        usernameWhoLiked: \"EventuallyEve\",
    });
    db.like.insertOne({_idL: 25, 
                        idLikedMessage: 11,
                        usernameWhoLiked: \"AlbertTheAxolotl\",
    });
    db.like.insertOne({_idL: 26, 
                        idLikedMessage: 13,
                        usernameWhoLiked: \"CallMeCathy\",
    });
    db.like.insertOne({_idL: 27, 
                        idLikedMessage: 14,
                        usernameWhoLiked: \"Ian95\",
    });
    db.like.insertOne({_idL: 28, 
                        idLikedMessage: 15,
                        usernameWhoLiked: \"J_TheJack\",
    });
    db.like.insertOne({_idL: 29, 
                        idLikedMessage: 15,
                        usernameWhoLiked: \"AlbertTheAxolotl\",
    });
    db.like.insertOne({_idL: 30, 
                        idLikedMessage: 15,
                        usernameWhoLiked: \"Ian95\",
    });
    db.like.insertOne({_idL: 31, 
                        idLikedMessage: 15,
                        usernameWhoLiked: \"BoxingBarbie\",
    });
    db.like.insertOne({_idL: 32, 
                        idLikedMessage: 15,
                        usernameWhoLiked: \"Gerald.\",
    });
    db.like.find({}, {_idL: 1, idLikedMessage: 1, usernamewhoLiked: 1}).forEach(printjson);
    print(\"You visualized the collection of all likes\");
"